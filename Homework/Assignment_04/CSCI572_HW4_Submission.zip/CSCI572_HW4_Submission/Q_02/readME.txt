
For my crawl I did IMDB, and mainly crawled movie pages.